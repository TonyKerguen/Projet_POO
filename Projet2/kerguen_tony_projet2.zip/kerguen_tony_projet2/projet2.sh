javac -d ./bin ./src/*.java
javadoc -d ./doc ./src/*.java
java -cp ./bin ExecutableVaisseau
